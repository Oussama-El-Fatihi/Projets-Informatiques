public abstract class  autreSignal extends signal { 
	protected double a0entree ;
	protected double[] anEntree ; 
	protected double[] bnEntree ;
	
	protected double a0sortie; 
	protected double[] anSortie ; 
	protected double[] bnSortie ; 
	protected double[] phiSortie;
	
	public autreSignal (double amplitude, double frequenceEntree, Filtre f){
		super (frequenceEntree, amplitude, f);
		calculCoeffBnEntree(); 
		calculCoeffAnEntree ();
		calculCoeffBnSortie();
		calculCoeffAnSortie();
		calculPhiSortie();
	}
	public abstract void calculCoeffBnEntree(); 
	public abstract void calculCoeffAnEntree();
	public abstract double calculSFEntree(double t );

	 
	
	public abstract double calculSFSortie(double t );
	
	
	
	
	public CurveFunction signalentree(){
		return ((x)->calculSFEntree(x));
	}
	
	public void calculCoeffAnSortie(){
		anSortie = new double [100] ;
		for (int i = 0 ; i<bnSortie.length; i++){
			anSortie[i] = anEntree[i]*f.CalculGain1((i+1)*frequence); 
		} 
	} 
	
	public void calculCoeffBnSortie(){
		bnSortie = new double [100] ;
		for (int i = 0 ; i<bnSortie.length; i++){
			bnSortie[i] = bnEntree[i]*f.CalculGain1((i+1)*frequence); 
		} 
	}
	
	public void calculPhiSortie(){
		phiSortie = new double [100] ;
		for (int i = 0 ; i<bnSortie.length; i++){
			phiSortie[i] =f.CalculPhi1((i+1)*frequence); 
		} 
	} 
	
	public void setFiltre(Filtre f){
		this.f = f;
		calculCoeffBnSortie();
		calculCoeffAnSortie();
		calculPhiSortie();
	}
	public void setfreq(double freq) {
		this.frequence = freq;
		calculCoeffBnSortie();
		calculCoeffAnSortie();
		calculPhiSortie();
	}
	public CurveFunction signalsortie(){
		return ((x)->calculSFSortie(x));
	}
	
}
