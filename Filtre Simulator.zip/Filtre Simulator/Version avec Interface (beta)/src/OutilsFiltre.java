public interface OutilsFiltre {
    public abstract double CalculGain();// normalement a enlever apres

    public abstract double CalculGain1(double f);

    public abstract double CalculPhi(); // a enlever apres

    public abstract double CalculPhi1(double f);

    public abstract double[] CalculFc(); // Fréquence de coupure

    public abstract double CalculFr(); // Fréquence de résonance

    public abstract void setR(double r);

    public abstract void setL(double l);

    public abstract void setC(double c);

    public abstract void setFreq(double freq);

    public abstract double CalculQual();

    public abstract double CalculBD();

    public abstract CurveFunction TraceGain(double r, double c);

    public abstract CurveFunction TracePhi(double r, double c);

    public abstract CurveFunction TracePhiRLC(double r, double l, double c);

    public abstract CurveFunction TraceGainRLC(double r, double l, double c);

    public abstract CurveFunction test(double a, double b);
}