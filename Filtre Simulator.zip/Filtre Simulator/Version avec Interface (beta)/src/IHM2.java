import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import javax.swing.event.ChangeEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import java.awt.*;
import javax.swing.ImageIcon;
import java.util.*;
import javax.swing.JComponent;
import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class IHM2 extends JFrame implements ActionListener, ChangeListener {

	// private Filtre FiltrF;
	private int ChoixAutre;
	private int FilChoi;
	private double micro = Math.pow(10, -9);
	private double mili = Math.pow(10, -3);
	private JButton sinButton;
	private JButton autreButton;
	private JLabel IntroSign;
	private Filtre FiltreF;
	private JSlider RSlide;
	private JSlider FreqSlide;
	private JLabel AmpLab;
	private JLabel Intro;
	private JSlider CSlide;
	private JSlider LSlide;
	private JLabel RLab;
	private JLabel CLab;
	private JLabel LLab;
	private JButton rlcButton;
	private JButton rcButton;
	private JButton rlButton;
	private JFrame FenSin;
	private JFrame FenRc;
	private JButton FinRC;
	private JTextField ParaC;
	private JTextField ParaR;
	private JPanel Cara;
	private JLabel Tixt;
	private JFrame FenAutre;
	private JLabel FcLabel;
	private JPanel PanSign;
	private JPanel panneauGlobal;
	private JLabel MessSin;
	private JButton Simple;
	private JButton Somme;
	private JButton plus;
	private JLabel LabAmp;
	private JLabel LabDecal;
	private JTextField AmpEntre;
	private JTextField DecaEntre;
	private JButton FinSin;
	private boolean choixSign = false;
	private int ChoixSin = 0;
	private JLabel ImageRC;
	private JLabel ImageRL;
	private JLabel ImageRLC;
	private signal Sign;
	private JLabel Pi;
	private double Freq;
	LinkedList<sinusoidal> sommeSin;
	private JLabel MessAutre;
	private JButton Carre;
	private JButton Scie;
	private JButton Trig;
	private JButton FinAutre;
	private JLabel LabAmp2;
	private JTextField AmpEntre2;;
	private JTextField freqsomme;
	private JLabel LabSomme;
	private TraceurCourbe GraphGain;
	private TraceurPhase GraphPhase;
	private TraceurSignal GraphEntree;
	private TraceurSignal GraphSortie;
	private JButton Gain;
	private JButton Phi;
	private JButton entree;
	private JButton sortie;
	private JLabel QualRLC;
	private JLabel FcRLC;
	private JLabel BDRLC;

	public IHM2() {
		this.setTitle("Filtre Simulator");
		this.setSize(600, 200);
		this.setLocation(0, 0);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);

		panneauGlobal = new JPanel();
		panneauGlobal.setBounds(0, 0, 1200, 1000);
		panneauGlobal.setLayout(null);
		panneauGlobal.setBackground(Color.gray);
		this.add(panneauGlobal);

		GraphGain = new TraceurCourbe("Gain");
		GraphPhase = new TraceurPhase("Phase");
		GraphSortie = new TraceurSignal("Signal Entrée");
		GraphEntree = new TraceurSignal("Signal Sortie");
		panneauGlobal.add(GraphGain);
		panneauGlobal.add(GraphPhase);
		panneauGlobal.add(GraphEntree);
		panneauGlobal.add(GraphSortie);

		// Panel Choix filtre

		JPanel choixFiltre = new JPanel();
		choixFiltre.setBounds(0, 0, 600, 200);
		choixFiltre.setLayout(null);
		choixFiltre.setBackground(Color.gray);
		panneauGlobal.add(choixFiltre);

		Intro = new JLabel();
		Intro.setText("Bonjour, veuillez choisir le type de filtre :");
		Intro.setBounds(20, 20, 300, 20);
		choixFiltre.add(Intro);

		Tixt = new JLabel();
		Tixt.setText("Filtre choisi : NA ");
		Tixt.setBounds(320, 20, 400, 20);
		Tixt.setBackground(Color.BLACK);
		choixFiltre.add(Tixt);

		rlcButton = new JButton("RLC");
		rlcButton.setBounds(50, 100, 100, 50);
		rlcButton.setBackground(Color.green);
		choixFiltre.add(rlcButton);
		rlcButton.addActionListener(this);

		rcButton = new JButton("RC");
		rcButton.setBounds(200, 100, 100, 50);
		rcButton.setBackground(Color.blue);
		choixFiltre.add(rcButton);
		rcButton.addActionListener(this);

		rlButton = new JButton("RL");
		rlButton.setBounds(350, 100, 100, 50);
		rlButton.setBackground(Color.red);
		choixFiltre.add(rlButton);
		rlButton.addActionListener(this);

		// Panneau de configuration

		Cara = new JPanel();
		Cara.setBounds(0, 200, 600, 800);
		Cara.setLayout(null);
		Cara.setBackground(Color.gray);
		panneauGlobal.add(Cara);

		FcLabel = new JLabel();
		FcLabel.setText("Fréquence de Résonance :");
		FcLabel.setForeground(Color.black);
		FcLabel.setBounds(150, 0, 300, 100);
		Cara.add(FcLabel);

		CSlide = new JSlider(100, 1100, 100);
		CSlide.setPaintTicks(true);
		CSlide.setPaintTrack(true);
		CSlide.setPaintLabels(true);
		CSlide.setBounds(20, 10, 100, 50);
		CSlide.addChangeListener(this);
		Cara.add(CSlide);

		CLab = new JLabel();
		CLab.setText("C = 0 µF");
		CLab.setForeground(Color.black);
		CLab.setBounds(20, 30, 100, 100);
		Cara.add(CLab);

		RSlide = new JSlider(100, 1100, 100);
		RSlide.setPaintTicks(true);
		RSlide.setPaintTrack(true);
		RSlide.setPaintLabels(true);
		RSlide.setBounds(20, 120, 100, 50);
		RSlide.addChangeListener(this);
		Cara.add(RSlide);

		RLab = new JLabel();
		RLab.setText("R = 0 Ω");
		RLab.setForeground(Color.black);
		RLab.setBounds(20, 130, 100, 100);
		Cara.add(RLab);

		LSlide = new JSlider(1, 100, 1);
		LSlide.setPaintTicks(true);
		LSlide.setPaintTrack(true);
		LSlide.setPaintLabels(true);
		LSlide.setBounds(20, 240, 100, 50);
		LSlide.addChangeListener(this);
		Cara.add(LSlide);

		LLab = new JLabel();
		LLab.setText("L = 0 mH");
		LLab.setForeground(Color.black);
		LLab.setBounds(20, 250, 100, 100);
		Cara.add(LLab);

		FreqSlide = new JSlider(1, 10000, 100);
		FreqSlide.setPaintTicks(true);
		FreqSlide.setPaintTrack(true);
		FreqSlide.setPaintLabels(true);
		FreqSlide.setBounds(20, 360, 100, 50);
		FreqSlide.setVisible(false);
		FreqSlide.addChangeListener(this);
		Cara.add(FreqSlide);

		AmpLab = new JLabel();
		AmpLab.setText("Fréquence = 0 Hz");
		AmpLab.setForeground(Color.black);
		AmpLab.setBounds(20, 370, 200, 100);
		AmpLab.setVisible(false);
		Cara.add(AmpLab);

		ImageRC = new JLabel(new ImageIcon("./img/RC_Image.png"));
		ImageRC.setBounds(150, 200, 300, 300);
		ImageRC.setVisible(false);
		Cara.add(ImageRC);

		ImageRL = new JLabel(new ImageIcon("./img/RL_Image.png"));
		ImageRL.setBounds(150, 200, 300, 300);
		ImageRL.setVisible(false);
		Cara.add(ImageRL);

		ImageRLC = new JLabel(new ImageIcon("./img/RLC_Image.png"));
		ImageRLC.setBounds(150, 200, 300, 300);
		ImageRLC.setVisible(false);
		Cara.add(ImageRLC);

		QualRLC = new JLabel();
		QualRLC.setText("Facteur Qualité du Filtre :");
		QualRLC.setForeground(Color.black);
		QualRLC.setBounds(150, 50, 300, 100);
		QualRLC.setVisible(false);
		Cara.add(QualRLC);

		FcRLC = new JLabel();
		FcRLC.setText("Fréquences de coupure du Filtre: ");
		FcRLC.setForeground(Color.black);
		FcRLC.setBounds(150, 100, 350, 100);
		FcRLC.setVisible(false);
		Cara.add(FcRLC);

		BDRLC = new JLabel();
		BDRLC.setText("Bande Passante du Filtre :  ");
		BDRLC.setForeground(Color.black);
		BDRLC.setBounds(150, 150, 300, 100);
		BDRLC.setVisible(false);
		Cara.add(BDRLC);

		this.setVisible(true);
		// Fenetre RC
		FenRc = new JFrame();
		FenRc.setTitle("Séléction des paramètres");
		FenRc.setSize(400, 500);

		JPanel PanRc = new JPanel();
		PanRc.setBounds(0, 0, 400, 500);
		PanRc.setLayout(null);
		PanRc.setBackground(Color.white);
		FenRc.add(PanRc);

		JLabel AffR = new JLabel();
		AffR.setText("Rentrer la valeur de R");
		AffR.setBounds(20, 20, 150, 20);
		PanRc.add(AffR);

		JLabel AffC = new JLabel();
		AffC.setText("Rentrer la valeur de C");
		AffC.setBounds(160, 20, 150, 20);
		PanRc.add(AffC);

		ParaR = new JTextField("X");
		ParaR.setBounds(50, 50, 50, 50);
		ParaR.setBackground(Color.green);
		PanRc.add(ParaR);

		ParaC = new JTextField("X");
		ParaC.setBounds(160, 50, 50, 50);
		ParaC.setBackground(Color.gray);
		PanRc.add(ParaC);

		FinRC = new JButton("FIN");
		FinRC.setBounds(140, 140, 75, 75);
		PanRc.add(FinRC);
		FinRC.addActionListener(this);

		// Fenetre Sinusoidal
		FenSin = new JFrame();
		FenSin.setTitle("Séléction de paramètre");
		FenSin.setSize(500, 500);

		JPanel PanSin = new JPanel();
		PanSin.setBounds(0, 0, 400, 500);
		PanSin.setLayout(null);
		PanSin.setBackground(Color.white);
		FenSin.add(PanSin);

		MessSin = new JLabel();
		MessSin.setText("Choisir le type de sinusoide :");
		MessSin.setBounds(10, 10, 300, 20);
		PanSin.add(MessSin);

		Simple = new JButton("SIMPLE");
		Simple.setBounds(50, 100, 150, 50);
		Simple.setBackground(Color.green);
		PanSin.add(Simple);
		Simple.addActionListener(this);

		Somme = new JButton("SOMME");
		Somme.setBounds(250, 100, 150, 50);
		Somme.setBackground(Color.orange);
		PanSin.add(Somme);
		Somme.addActionListener(this);

		LabAmp = new JLabel();
		LabAmp.setText("Entrer l'Amplitude A (V):");
		LabAmp.setBounds(50, 100, 150, 150);
		PanSin.add(LabAmp);
		LabAmp.setVisible(false);

		LabDecal = new JLabel();
		LabDecal.setText("Entrer le décalage Ѱ :");
		LabDecal.setBounds(250, 100, 150, 150);
		PanSin.add(LabDecal);
		LabDecal.setVisible(false);

		Pi = new JLabel();
		Pi.setText("π");
		Pi.setBounds(300, 200, 150, 50);
		PanSin.add(Pi);
		Pi.setVisible(false);

		AmpEntre = new JTextField();
		AmpEntre.setText("");
		AmpEntre.setBounds(50, 200, 50, 50);
		PanSin.add(AmpEntre);
		AmpEntre.setVisible(false);

		DecaEntre = new JTextField();
		DecaEntre.setText("");
		DecaEntre.setBounds(250, 200, 50, 50);
		PanSin.add(DecaEntre);
		DecaEntre.setVisible(false);

		FinSin = new JButton("Fin");
		FinSin.setBounds(150, 400, 150, 50);
		FinSin.setBackground(Color.orange);
		PanSin.add(FinSin);
		FinSin.addActionListener(this);
		FinSin.setVisible(false);

		plus = new JButton("+");
		plus.setBounds(400, 250, 50, 50);
		PanSin.add(plus);
		plus.addActionListener(this);
		plus.setVisible(false);

		freqsomme = new JTextField();
		freqsomme.setBounds(180, 330, 100, 50);
		PanSin.add(freqsomme);
		freqsomme.setVisible(false);

		LabSomme = new JLabel();
		LabSomme.setBounds(150, 280, 200, 50);
		LabSomme.setText("Entrer la fréquence du Signal");
		PanSin.add(LabSomme);
		LabSomme.setVisible(false);

		FenAutre = new JFrame();
		FenAutre.setTitle("Sélection des paramètres");
		FenAutre.setSize(700, 700);

		JPanel PanAutre = new JPanel();
		PanAutre.setBounds(0, 0, 400, 500);
		PanAutre.setLayout(null);
		PanAutre.setBackground(Color.white);
		FenAutre.add(PanAutre);

		MessAutre = new JLabel();
		MessAutre.setText("Choisir le type de signal :");
		MessAutre.setBounds(10, 10, 300, 20);
		PanAutre.add(MessAutre);

		Scie = new JButton("Dents de Scie");
		Scie.setBounds(50, 100, 150, 50);
		Scie.setBackground(Color.green);
		PanAutre.add(Scie);
		Scie.addActionListener(this);

		Carre = new JButton("Carré");
		Carre.setBounds(220, 100, 150, 50);
		Carre.setBackground(Color.orange);
		PanAutre.add(Carre);
		Carre.addActionListener(this);

		Trig = new JButton("Triangle");
		Trig.setBounds(380, 100, 150, 50);
		Trig.setBackground(Color.red);
		PanAutre.add(Trig);
		Trig.addActionListener(this);

		LabAmp2 = new JLabel();
		LabAmp2.setText("Entrer l'Amplitude A (V):");
		LabAmp2.setBounds(50, 100, 150, 150);
		PanAutre.add(LabAmp2);
		LabAmp2.setVisible(false);

		AmpEntre2 = new JTextField();
		AmpEntre2.setText("");
		AmpEntre2.setBounds(50, 200, 150, 50);
		PanAutre.add(AmpEntre2);
		AmpEntre2.setVisible(false);

		FinAutre = new JButton("Fin");
		FinAutre.setBounds(150, 400, 150, 50);
		FinAutre.setBackground(Color.orange);
		PanAutre.add(FinAutre);
		FinAutre.addActionListener(this);
		FinAutre.setVisible(false);

		PanSign = new JPanel();
		PanSign.setBounds(600, 0, 600, 200);
		PanSign.setLayout(null);
		PanSign.setBackground(Color.gray);
		panneauGlobal.add(PanSign);
		PanSign.setVisible(false);

		IntroSign = new JLabel();
		IntroSign.setText("Maintenant, veuillez choisir le type de signal :");
		IntroSign.setBackground(Color.white);
		IntroSign.setBounds(20, 20, 300, 20);
		PanSign.add(IntroSign);

		sinButton = new JButton("SINUSOIDAL");
		sinButton.setBounds(50, 100, 150, 50);
		sinButton.setBackground(Color.green);
		PanSign.add(sinButton);
		sinButton.addActionListener(this);

		autreButton = new JButton("AUTRE TYPE");
		autreButton.setBounds(250, 100, 150, 50);
		autreButton.setBackground(Color.blue);
		PanSign.add(autreButton);
		autreButton.addActionListener(this);

		Gain = new JButton("Gain");
		Gain.setBounds(500, 10, 100, 50);
		Cara.add(Gain);
		Gain.addActionListener(this);

		Phi = new JButton("Phase");
		Phi.setBounds(500, 65, 100, 50);
		Cara.add(Phi);
		Phi.addActionListener(this);

		entree = new JButton("Entrée");
		entree.setBounds(500, 120, 100, 50);
		Cara.add(entree);
		entree.addActionListener(this);

		sortie = new JButton("Sortie");
		sortie.setBounds(500, 175, 100, 50);
		Cara.add(sortie);
		sortie.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == Gain) {
			GraphPhase.setVisible(false);
			GraphEntree.setVisible(false);
			GraphSortie.setVisible(false);
			GraphGain.setVisible(true);
		} else {
			if (e.getSource() == Phi) {
				GraphEntree.setVisible(false);
				GraphGain.setVisible(false);
				GraphSortie.setVisible(false);
				GraphPhase.setVisible(true);
			} else {
				if (e.getSource() == entree) {
					GraphGain.setVisible(false);
					GraphPhase.setVisible(false);
					GraphSortie.setVisible(false);
					GraphEntree.setVisible(true);
				} else {
					if (e.getSource() == sortie) {
						GraphGain.setVisible(false);
						GraphPhase.setVisible(false);
						GraphEntree.setVisible(false);
						GraphSortie.setVisible(true);
					}
				}

			}
		}

		if (FilChoi == 0) {
			if (e.getSource() == rcButton) {
				ImageRC.setVisible(true);
				GraphGain.setVisible(true);
				FilChoi = 1;
				System.out.println("Choisir la valeur de R et C");
				Intro.setText("Choisir la valeur de R et C");
				Tixt.setText("Filtre choisi : RC");
				FiltreF = new RC();
				System.out.println(FiltreF);
				PanSign.setVisible(true);
				this.setSize(1200, 1000);

			} else {
				if (e.getSource() == rlcButton) {
					ImageRLC.setVisible(true);
					GraphGain.setVisible(true);
					FilChoi = 2;
					FiltreF = new RLC();
					System.out.println("Choisir la valeur de L, R et C");
					Intro.setText("Choisir la valeur de L, R et C");
					Tixt.setText("Filtre choisi : RLC");
					PanSign.setVisible(true);
					this.setSize(1200, 1000);
					BDRLC.setVisible(true);
					FcRLC.setVisible(true);
					QualRLC.setVisible(true);

				} else {
					if (e.getSource() == rlButton) {
						ImageRL.setVisible(true);
						GraphGain.setVisible(true);
						System.out.println("Choisir la valeur de L et R");
						Intro.setText("Choisir la valeur de L et C");
						Tixt.setText("Filtre choisi : RL");
						FilChoi = 3;
						FiltreF = new RL();
						PanSign.setVisible(true);
						this.setSize(1200, 1000);

					}

				}

			}

		} else {
			if (!choixSign) {
				if (e.getSource() == sinButton) {
					FenSin.setVisible(true);
					choixSign = true;

				} else {
					if (e.getSource() == autreButton) {
						FenAutre.setVisible(true);
						choixSign = true;
					}
				}
			}
		}

		if (choixSign) {
			if (e.getSource() == Simple) {
				ChoixSin = 1;
				FinSin.setVisible(true);
				DecaEntre.setVisible(true);
				AmpEntre.setVisible(true);
				LabDecal.setVisible(true);
				LabAmp.setVisible(true);
				LabAmp.setVisible(true);
				Pi.setVisible(true);
			} else {
				if (e.getSource() == Somme) {
					FinSin.setVisible(true);
					DecaEntre.setVisible(true);
					AmpEntre.setVisible(true);
					LabDecal.setVisible(true);
					LabAmp.setVisible(true);
					plus.setVisible(true);
					Pi.setVisible(true);
					freqsomme.setVisible(true);
					LabSomme.setVisible(true);

					ChoixSin = 2;
					sommeSin = new LinkedList<sinusoidal>();

				} else {
					if ((e.getSource() == Carre)) {
						ChoixSin = 1;
						ChoixAutre = 1;
						FinAutre.setVisible(true);

						AmpEntre2.setVisible(true);

						LabAmp2.setVisible(true);

					} else {
						if (e.getSource() == Trig) {
							ChoixSin = 1;
							ChoixAutre = 2;
							FinAutre.setVisible(true);

							AmpEntre2.setVisible(true);

							LabAmp2.setVisible(true);

						} else {
							if (e.getSource() == Scie) {
								ChoixSin = 1;
								ChoixAutre = 3;
								FinAutre.setVisible(true);
								AmpEntre2.setVisible(true);

								LabAmp2.setVisible(true);

							}

						}
					}
				}
			}
			if (ChoixSin != 0) {
				if ((e.getSource() == FinSin) && (ChoixSin == 1)) {
					Sign = new sinusoidal(Freq, Double.parseDouble(AmpEntre.getText()),
							Double.parseDouble(DecaEntre.getText()) * Math.PI, FiltreF);
					FenSin.setVisible(false);
					System.out.println(Sign);
					FreqSlide.setVisible(true);
					AmpLab.setVisible(true);

				} else {
					if ((e.getSource() == plus) && (ChoixSin == 2)) {
						sommeSin.add(new sinusoidal(Double.parseDouble(freqsomme.getText()),
								Double.parseDouble(AmpEntre.getText()),
								Double.parseDouble(DecaEntre.getText()) * Math.PI, FiltreF));
						AmpEntre.setText("");
						DecaEntre.setText("");
						freqsomme.setText("");
					} else {
						if ((e.getSource() == FinSin) && (ChoixSin == 2)) {

							FenSin.setVisible(false);

							GraphEntree.setFunction(sommeSin.getFirst().sommeSignalEntree(sommeSin),
									4 / sommeSin.getFirst().freqMin(sommeSin));
							GraphSortie.setFunction(sommeSin.getFirst().sommeSignalSortie(sommeSin),
									4 / sommeSin.getFirst().freqMin(sommeSin));
						} else {
							if ((e.getSource() == FinAutre)) {
								FreqSlide.setVisible(true);
								AmpLab.setVisible(true);
								FenAutre.setVisible(false);
								if (ChoixAutre == 1) {
									Sign = new carre(Double.parseDouble(AmpEntre2.getText()), Freq, FiltreF);
								} else {
									if (ChoixAutre == 2) {
										Sign = new triangle(Double.parseDouble(AmpEntre2.getText()), Freq, FiltreF);
									} else {
										if (ChoixAutre == 3) {
											Sign = new dentDeScie(Double.parseDouble(AmpEntre2.getText()), Freq,
													FiltreF);
										}
									}
								}

							}

						}
					}
				}

			}

		}
	}

	public void stateChanged(ChangeEvent e) {
		if (FilChoi != 0) {

			if (e.getSource() == FreqSlide) {
				AmpLab.setText("Fréquence = " + FreqSlide.getValue() + " Hz");
				Freq = FreqSlide.getValue();
				System.out.println(FiltreF.CalculGain1(FreqSlide.getValue()));

				if (ChoixSin == 1) {
					Sign.setfreq(Freq);

					GraphEntree.setFunction(Sign.signalentree(), (2 / Sign.frequence));
					GraphSortie.setFunction(Sign.signalsortie(), (2 / Sign.frequence));

				}
			}
			if ((FilChoi == 1)) {
				if (e.getSource() == CSlide) {
					CLab.setText("C = " + CSlide.getValue() * 0.001 + "µF");
					FiltreF.setC(CSlide.getValue() * micro);
					FcLabel.setText("Fréquence de Résonance : " + FiltreF.CalculFr() + " Hz");
					GraphGain.setFunction(FiltreF.TraceGain(RSlide.getValue(), CSlide.getValue() * micro));
					GraphPhase.setFunction(FiltreF.TracePhi(RSlide.getValue(), CSlide.getValue() * micro));
					if (ChoixSin == 1) {
						Sign.setFiltre(FiltreF);
						GraphEntree.setFunction(Sign.signalentree());
						GraphSortie.setFunction(Sign.signalsortie());
						System.out.println("C'est Fait ! ");
					} else {
						if (ChoixSin == 2) {
							for (sinusoidal Som : sommeSin) {
								Som.setFiltre(FiltreF);
							}
							GraphEntree.setFunction(sommeSin.getFirst().sommeSignalEntree(sommeSin));
							GraphSortie.setFunction(sommeSin.getFirst().sommeSignalSortie(sommeSin));
							System.out.println("C'est Fait ! ");
						}
					}
				} else {
					if (e.getSource() == RSlide) {
						RLab.setText("R = " + RSlide.getValue() + "Ω");
						FiltreF.setR(RSlide.getValue());
						FcLabel.setText("Fréquence de Résonance : " + FiltreF.CalculFr() + " Hz");
						GraphGain.setFunction(FiltreF.TraceGain(RSlide.getValue(), CSlide.getValue() * micro));
						GraphPhase.setFunction(FiltreF.TracePhi(RSlide.getValue(), CSlide.getValue() * micro));
						if (ChoixSin == 1) {
							Sign.setFiltre(FiltreF);
							GraphEntree.setFunction(Sign.signalentree());
							GraphSortie.setFunction(Sign.signalsortie());
							System.out.println("C'est Fait ! ");
						} else {
							if (ChoixSin == 2) {
								for (sinusoidal Som : sommeSin) {
									Som.setFiltre(FiltreF);
								}
								GraphEntree.setFunction(sommeSin.getFirst().sommeSignalEntree(sommeSin));
								GraphSortie.setFunction(sommeSin.getFirst().sommeSignalSortie(sommeSin));
								System.out.println("C'est Fait ! ");
							}
						}
					}
				}
			} else {
				if ((FilChoi == 2)) {
					if (e.getSource() == CSlide) {
						CLab.setText("C = " + CSlide.getValue() * 0.001 + "µF");
						FiltreF.setC(CSlide.getValue() * micro);
						FcLabel.setText("Fréquence de Résonance : " + FiltreF.CalculFr() + " Hz");

						QualRLC.setText("Facteur Qualité du Filtre :" + FiltreF.CalculQual());
						FcRLC.setText("Fréquences de coupure du Filtre : " + FiltreF.CalculFc()[0] + " Hz, "
								+ FiltreF.CalculFc()[0] + " Hz");
						BDRLC.setText("Bande Passante du Filtre : " + FiltreF.CalculBD() + " Hz");

						GraphGain.setFunction(
								FiltreF.TraceGainRLC(RSlide.getValue(), LSlide.getValue() * mili,
										CSlide.getValue() * micro));
						GraphPhase.setFunction(
								FiltreF.TracePhiRLC(RSlide.getValue(), LSlide.getValue() * mili,
										CSlide.getValue() * micro));
						if (ChoixSin == 1) {
							Sign.setFiltre(FiltreF);
							GraphEntree.setFunction(Sign.signalentree());
							GraphSortie.setFunction(Sign.signalsortie());
						} else {
							if (ChoixSin == 2) {
								for (sinusoidal Som : sommeSin) {
									Som.setFiltre(FiltreF);
								}
								GraphEntree.setFunction(sommeSin.getFirst().sommeSignalEntree(sommeSin));
								GraphSortie.setFunction(sommeSin.getFirst().sommeSignalSortie(sommeSin));
							}
						}

					} else {
						if (e.getSource() == RSlide) {
							RLab.setText("R = " + RSlide.getValue() + "Ω");
							FiltreF.setR(RSlide.getValue());
							FcLabel.setText("Fréquence de Résonance : " + FiltreF.CalculFr() + " Hz");

							QualRLC.setText("Facteur Qualité du Filtre :" + FiltreF.CalculQual());
							FcRLC.setText("Fréquences de coupure du Filtre : " + FiltreF.CalculFc()[0] + " Hz, "
									+ FiltreF.CalculFc()[0] + " Hz");
							BDRLC.setText("Bande Passante du Filtre : " + FiltreF.CalculBD() + " Hz");
							GraphGain.setFunction(
									FiltreF.TraceGainRLC(RSlide.getValue(), LSlide.getValue() * mili,
											CSlide.getValue() * micro));
							GraphPhase.setFunction(
									FiltreF.TracePhiRLC(RSlide.getValue(), LSlide.getValue() * mili,
											CSlide.getValue() * micro));
							if (ChoixSin == 1) {
								Sign.setFiltre(FiltreF);
								GraphEntree.setFunction(Sign.signalentree());
								GraphSortie.setFunction(Sign.signalsortie());
							} else {
								if (ChoixSin == 2) {
									for (sinusoidal Som : sommeSin) {
										Som.setFiltre(FiltreF);
									}
									GraphEntree.setFunction(sommeSin.getFirst().sommeSignalEntree(sommeSin));
									GraphSortie.setFunction(sommeSin.getFirst().sommeSignalSortie(sommeSin));
								}
							}

						} else {
							if (e.getSource() == LSlide) {
								LLab.setText("L = " + LSlide.getValue() + "mH");
								FiltreF.setL(LSlide.getValue() * mili);
								FcLabel.setText("Fréquence de Résonance : " + FiltreF.CalculFr() + " Hz");

								QualRLC.setText("Facteur Qualité du Filtre :" + FiltreF.CalculQual());
								FcRLC.setText("Fréquences de coupure du Filtre : " + FiltreF.CalculFc()[0] + " Hz, "
										+ FiltreF.CalculFc()[0] + " Hz");
								BDRLC.setText("Bande Passante du Filtre : " + FiltreF.CalculBD() + " Hz");
								GraphGain.setFunction(
										FiltreF.TraceGainRLC(RSlide.getValue(), LSlide.getValue() * mili,
												CSlide.getValue() * micro));
								GraphPhase.setFunction(
										FiltreF.TracePhiRLC(RSlide.getValue(), LSlide.getValue() * mili,
												CSlide.getValue() * micro));
								if (ChoixSin == 1) {
									Sign.setFiltre(FiltreF);
									GraphEntree.setFunction(Sign.signalentree());
									GraphSortie.setFunction(Sign.signalsortie());
								} else {
									if (ChoixSin == 2) {
										for (sinusoidal Som : sommeSin) {
											Som.setFiltre(FiltreF);
										}
										GraphEntree.setFunction(sommeSin.getFirst().sommeSignalEntree(sommeSin));
										GraphSortie.setFunction(sommeSin.getFirst().sommeSignalSortie(sommeSin));
									}

								}

							}
						}
					}
				} else {
					if ((FilChoi == 3)) {

						if (e.getSource() == RSlide) {
							RLab.setText("R = " + RSlide.getValue() + "Ω");
							FiltreF.setR(RSlide.getValue());
							FcLabel.setText("Fréquence de Résonance : " + FiltreF.CalculFr() + " Hz");
							GraphGain.setFunction(FiltreF.TraceGain(LSlide.getValue() * mili, RSlide.getValue()));
							GraphPhase.setFunction(FiltreF.TracePhi(RSlide.getValue(), LSlide.getValue() * mili));
							if (ChoixSin == 1) {
								Sign.setFiltre(FiltreF);
								GraphEntree.setFunction(Sign.signalentree());
								GraphSortie.setFunction(Sign.signalsortie());
							} else {
								if (ChoixSin == 2) {
									for (sinusoidal Som : sommeSin) {
										Som.setFiltre(FiltreF);
									}
									GraphEntree.setFunction(sommeSin.getFirst().sommeSignalEntree(sommeSin));
									GraphSortie.setFunction(sommeSin.getFirst().sommeSignalSortie(sommeSin));
								}
							}

						} else {
							if (e.getSource() == LSlide) {
								LLab.setText("L = " + LSlide.getValue() + "mH");
								FiltreF.setL(LSlide.getValue() * mili);
								FcLabel.setText("Fréquence de Résonance : " + FiltreF.CalculFr() + " Hz");
								GraphGain.setFunction(FiltreF.TraceGain(LSlide.getValue() * mili, RSlide.getValue()));
								GraphPhase.setFunction(FiltreF.TracePhi(RSlide.getValue(), LSlide.getValue() * mili));
								if (ChoixSin == 1) {
									Sign.setFiltre(FiltreF);
									GraphEntree.setFunction(Sign.signalentree());
									GraphSortie.setFunction(Sign.signalsortie());
								} else {
									if (ChoixSin == 2) {
										for (sinusoidal Som : sommeSin) {
											Som.setFiltre(FiltreF);
										}
										GraphEntree.setFunction(sommeSin.getFirst().sommeSignalEntree(sommeSin));
										GraphSortie.setFunction(sommeSin.getFirst().sommeSignalSortie(sommeSin));
									}
								}
							}
						}
					}

				}
			}
		}

	}

}
