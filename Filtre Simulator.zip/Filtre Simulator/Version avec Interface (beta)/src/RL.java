public class RL extends Filtre {
    protected double R;
    protected double L;

    public RL(double f, double r, double l) {
        super(f); // Ã vÃ©rifier
        this.R = r;
        this.L = l;

    }

    public RL() {
        super(0);
        R = 0;
        L = 0;

    }

    public String toString() {
        return super.toString() + " composÃ©e d'une rÃ©sistance de " + this.R + " Ohm et d'un condensateur de " + this.L
                + " F.";
    }

    public double CalculGain() {
        double a = L * 2 * Math.PI / R;
        return (a * this.frequence / Math.pow(1 + Math.pow(a * this.frequence, 2), 0.5));
    }

    public double CalculGain1(double f) {
        double a = L * 2 * Math.PI / R;
        return (a * f / Math.pow(1 + Math.pow(a * f, 2), 0.5));
    }

    public double CalculPhi() {
        double a = L * 2 * Math.PI / R;
        return (-Math.PI / 2 - Math.atan(a * this.frequence));
    }

    public double CalculPhi1(double f) {
        double a = L * 2 * Math.PI / R;
        return (-Math.PI / 2 - Math.atan(a * f));
    }

    public double CalculFr() {
        return Math.round((this.R / (this.L * 2 * Math.PI)) * 100.0) / 100.0;
        // return (1 / this.R * this.C * 2 * Math.PI);
    }

    public void setR(double r) {
        this.R = r;
    }

    public void setL(double l) {
        this.L = l;
    }

    public void setFreq(double freq) {
        this.frequence = freq;
    }

    public CurveFunction TracePhi(double r, double l) {
        return ((x) -> (Math.atan(r / (l * x * 2 * Math.PI))));
    }

    public CurveFunction TraceGain(double l, double r) {

        return ((x) -> ((l * x * 2 * Math.PI / r) / Math.pow(1 + Math.pow((l * x * 2 * Math.PI / r), 2), 0.5)));
    }

    public CurveFunction test(double a, double b) {
        return (x) -> a * x + b;
    }

}
