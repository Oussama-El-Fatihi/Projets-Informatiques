import java.util.*;

public class sinusoidal extends signal {
	/**
	 * Classe signal : permet de générer un signal sinusoidal et sera également utilisé
	 * pour générer un signal constitué d'une somme de signaux sinusoidaux
	 */
	 
	protected double phaseEntree;//phase à l'origine avant filtrage
	protected double amplitudeSortie;//amplitude du signal après filtrage
	protected double phaseSortie;//phase a l'origine après filtrage
	
	
	/**
	 * constructeur
	 * @param fréquence du générateur
	 * @param amplitude du signal
	 * @param phase à l'origine avant filtrage
	 * @param filtre appliqué au signal
	 */
	public sinusoidal(double frequence, double amplitude, double phase, Filtre f1) {
		super(frequence, amplitude, f1);
		phaseEntree = phase;
		this.sortie();
	}
	
	
	/**
	 *calcul l'amplitude et la phase à l'origine après filtrage
	 */
	public void sortie() {
		this.amplitudeSortie = this.amplitudeEntree * this.f.CalculGain1(this.frequence);
		this.phaseSortie = this.phaseEntree + this.f.CalculPhi1(this.frequence);

	}
	
    /**
	 *Affichage des attributs de la classe pour tester la classe
	 */
	public String toString() {
		return "signal sinusoidal de fréquence" + this.frequence + " Hz" + "d'amplitude" + this.amplitudeEntree
				+ "de phase"
				+ this.phaseEntree + "avec un filtre de type" + this.f;
	}
	
	
	/**
	 * fixe le filtre utilisé
	 * @param filtre
	 */
	public void setFiltre(Filtre f) {
		this.f = f;
		this.sortie();//mise à jour des amplitudes et phase à l'origine après filtrage
	}
	
	/**
	 * fixe la fréquence du générateur
	 * @param fréquence
	 */
	public void setfreq(double freq) {
		this.frequence = freq;
		this.sortie();//mise à jour des amplitudes et phase à l'origine après filtrage
	}
	
	
	/**
	 *determine la fréquence min d'un signal constitué d'une somme de signaux sinusoidaux 
	 * pour que l'affichage soit correct 
	 * @param une LinkedList contenant les sinusoidals formant le signal
	 * @return frqmin
	 */
	public double freqMin(LinkedList<sinusoidal> a){
		double frqmin=a.get(0).frequence;
		for (sinusoidal s : a) {
			if(s.frequence<frqmin){
				frqmin=s.frequence;
			}
		}
		return frqmin;
	}

	/**
	 *traçe le signal d'entrée
	 */
	public CurveFunction signalentree() {
		this.sortie();
		return (x) -> amplitudeEntree * Math.cos(2 * Math.PI * frequence * x + phaseEntree);
	}

	/**
	 *traçe le signal de sortie 
	 */
	public CurveFunction signalsortie() {
		this.sortie();
		return (x) -> amplitudeSortie * Math.cos(2 * Math.PI * frequence * x + phaseSortie);

	}
	
	
	/**
	 *calcul l'amplitude d'un signal constitué d'une somme de signaux sinusoidaux pour un t donné avant filtrage
	 * @param signal
	 * @param t temps
	 * @return l'amplitude à un t donné
	 */
	public double calculSommeEntree(LinkedList<sinusoidal> a, double t) {
		double somme = 0;
		for (sinusoidal s : a) {
			somme = somme + s.amplitudeEntree * Math.cos(2 * Math.PI * s.frequence * t + s.phaseEntree);
		}
		return somme;
	}

	/**
	 *traçe le signal avant filtrage d'un signal constitué d'une somme de signaux sinusoidaux
	 * @param signal
	 */
	public CurveFunction sommeSignalEntree(LinkedList<sinusoidal> sommeSinusoide) {
		return (x) -> calculSommeEntree(sommeSinusoide, x);

	}
	
	/**
	 *calcul l'amplitude d'un signal constitué d'une somme de signaux sinusoidaux pour un t donné après filtrage
	 * @param signal
	 * @param t temps
	 * @return l'amplitude à un t donné
	 */
	public double calculSommeSortie(LinkedList<sinusoidal> a, double t) {
		double somme = 0;
		for (sinusoidal s : a) {
			somme = somme + s.amplitudeSortie * Math.cos(2 * Math.PI * s.frequence * t + s.phaseSortie);
		}
		return somme;
	}
	
	
	/**
	 *traçe le signal de sortie d'un signal constitué d'une somme de signaux sinusoidaux
	 * @param signal
	 */
	public CurveFunction sommeSignalSortie(LinkedList<sinusoidal> sommeSinusoide) {
		return (x) -> calculSommeSortie(sommeSinusoide, x);

	}
	


}

