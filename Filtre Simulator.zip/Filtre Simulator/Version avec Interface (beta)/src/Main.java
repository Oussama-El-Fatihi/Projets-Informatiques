public class Main {
    public static void main(String args[]) {
        IHM2 monPRojet2 = new IHM2();

    }
}