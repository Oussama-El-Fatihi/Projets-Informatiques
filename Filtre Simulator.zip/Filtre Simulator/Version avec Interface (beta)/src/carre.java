public class carre extends autreSignal {
	
	public carre (double amplitude, double frequenceEntree, Filtre f ){
		super (amplitude,frequenceEntree, f) ;
		a0entree=0;
		a0sortie=0;
		
		}
	
	//entree
	 
	public void calculCoeffBnEntree(){
		bnEntree = new double [100];
		for (int i = 0 ; i< bnEntree.length ; i++) {
			bnEntree[i]= (2*amplitudeEntree*(1- Math.pow((-1),(i+1) ) ) )/((i+1)*Math.PI) ; 
			
		}
			
	}
	public void calculCoeffAnEntree(){ // an = 0 donc ok
		anEntree = new double [100]; 
	} 
	
	public double calculSFEntree(double t){
		double sf=0;
		for(int i=0;i<bnEntree.length;i++){
			sf=sf+bnEntree[i]*Math.sin(2*Math.PI*frequence*(i+1)*t);
		}
		
		
		return sf;
	}
	
	//sortie
	
	
	public double calculSFSortie(double t){
		double sf=0;
		for(int i=0;i<bnEntree.length;i++){
			sf=sf+bnSortie[i]*Math.sin(2*Math.PI*frequence*(i+1)*t+phiSortie[i]);
		}
		return sf;
	}
	
	
	
	
	
	
	
}

