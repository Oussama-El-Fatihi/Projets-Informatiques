public class RC extends Filtre  {
	/**
	 * Classe RC : permet de générer un filtre RC
	 */

    protected double R;//  valeur de la résistance 
    protected double C;// valeur du condensteur
    protected double w0;//pulsation de résonnance
	
    
	/**
	 * constructeur
	 * @param fréquence du signql à filtrer
	 * @param résistance 
	 * @param condensateur
	 */
    public RC(double f, double r, double c) {
        super(f); 
        this.R = r;
        this.C = c;
        w0 = 1 / (R * C);

    }


	/**
	 * constructeur
	 * fréquence, résistance, condensateur fixées à zéro
	 */
    public RC() {
        super(0);
        R = 0;
        C = 0;
    }

    
	/**
	 * permet de tester les valeurs de résistance et condensateurs
	 */
    public String toString() {
        return super.toString() + " composÃ©e d'une rÃ©sistance de " + this.R + " Ohm et d'un condensateur de " + this.C
                + " F."; // Permet le test d'affectation
    }


    /**
	 *calcul le gain à une certaine fréquence
	 * @param fréquence
	 * @return le gain à la fréquence donnée
	 */	
    public double CalculGain1(double f) {
        return ((Math.pow(1 + Math.pow(this.R * this.C * f * 2 * Math.PI, 2), -0.5)));
    }

   
   
   	/**
	 *calcul le déphasage à une certaine fréquence
	 * @param fréquence
	 * @return le déphasage à la fréquence donnée
	 */
    public double CalculPhi1(double f) {
        return (-1 * Math.atan(this.R * this.C * f * 2 * Math.PI));
    }
    
    
    
    /**
	 *calcul la fréquence de résonnance 
	 * @return la fréquence de résonnance 
	 */
    public double CalculFr() {

        double F = (Math.round((1 / (this.R * this.C * 2 * Math.PI)) * 100.0) /
                100.0);
        if (F > 25000) { // condition limitiant le bug d'affichage du à la grande valeur de cette
            // fréquence
            return 2500;
        } else {
            return F;

        }

    }
    
    /**
	 * calcul la bande passante pour le filtre RLC
	 * @return bande passante
	 */
	 public double CalculBD(){
		 return 0;
	 }
	 
    
    
    /**
	 *calcul les fréquences de coupure pour le filtre RLC
	 * @return deux fréquences de coupure
	 */
    public double[] CalculFc() {
        double[] tab = new double[2];//on retourne rien car pas deux fréquences de résonnance pour filtre RL
        return tab;
    }
    

	/**
	 * fixe la valeur de la résistance
	 * @param résistance
	 */
    public void setR(double r) {
        this.R = r;
    }

    /**
	 * fixe la valeur de la bobbine
	 * @param bobbine
	 */
    public void setL(double l) {
        this.R = R;//car pas de bobbine
    }
    
    /**
	 * fixe la valeur du condensateur
	 * @param condensateur
	 */
    public void setC(double c) {
        this.C = c;
    }
    
    
    
    /**
	 * fixe la fréquence 
	 * @param fréquence
	 */
    public void setFreq(double freq) {
        this.frequence = freq;
    }
    
    
    /**
	 *calcule le facteur qualité pour le filtre RLC
	 * @return facteur qualité
	 */
    public double CalculQual() {
        return 0;//pas de faceteur qualité pour RC
    }

	/**
	 *traçe le déphasage en fonction de la fréquence
	 * @param résistance
	 * @param condensateur ou bobbine
	 */
    public CurveFunction TracePhi(double r, double c) {
        return ((x) -> -1 * Math.atan(r * c * x * 2 * Math.PI));
    }
    
    
   
    /**
	 *traçe le gain en fonction de la fréquence
	 * @param résistance
	 * @param condensateur ou bobbine
	 */
    public CurveFunction TraceGain(double r, double c) {
        return ((x) -> (1 / (Math.pow(1 + Math.pow(r * c * x * 2 * Math.PI, 2), 0.5))));
    }


    /**
	 *test le tracé
	 * @param a quelconque
	 * @param b quelconque
	 */
    public CurveFunction test(double a, double b) {
        return (x) -> a * x + b;
    }


    /**
	 *traçe le déphasage pour RLC en fonction de la fréquence
	 * @param résistance
	 * @param condensateur 
	 * @param bobbine
	 */
    public CurveFunction TracePhiRLC(double r, double l, double c) {
        return null;// car pas RLC
    }


    /**
	 *traçe le gain en fonction de la fréquence pour RLC
	 * @param résistance
	 * @param condensateur 
	 * @param bobbine
	 */
    public CurveFunction TraceGainRLC(double r, double l, double c) {
        return null;//car pas RLC
    }
}
