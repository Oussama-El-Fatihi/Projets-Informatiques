public class RC extends Filtre {
    protected double R;
    protected double C;
    protected double w0;

    public RC(double f, double r, double c) {
        super(f); // Ã vÃ©rifier
        this.R = r;
        this.C = c;
        w0 = 1 / (R * C);

    }

    public RC() {
        super(0);
        R = 0;
        C = 0;
    }

    public String toString() {
        return super.toString() + " composÃ©e d'une rÃ©sistance de " + this.R + " Ohm et d'un condensateur de " + this.C
                + " F."; // Permet le test d'affectation
    }

    public double CalculGain() {
        return ((Math.pow(1 + Math.pow(this.R * this.C * this.frequence * 2 * Math.PI, 2), -0.5)));
    }

    public double CalculGain1(double f) {
        return ((Math.pow(1 + Math.pow(this.R * this.C * f * 2 * Math.PI, 2), -0.5)));
    }

    public double CalculPhi() {
        return (-1 * Math.atan(this.R * this.C * this.frequence * 2 * Math.PI));
    }

    public double CalculPhi1(double f) {
        return (-1 * Math.atan(this.R * this.C * f * 2 * Math.PI));
    }

    public double CalculFr() {
        // return Math.round((1 / (this.R * this.C * 2 * Math.PI)) * 100.0) / 100.0;

        double F = (Math.round((1 / (this.R * this.C * 2 * Math.PI)) * 100.0) /
                100.0);
        if (F > 25000) { // condition limitiant le bug d'affichage du à la grande valeur de cette
            // fréquence
            return 2500;
        } else {
            return Math.round((1 / (this.R * this.C * 2 * Math.PI)) * 100.0) / 100.0;

        }

    }

    public double[] CalculFc() {
        double[] tab = new double[2];
        tab[0] = Math.round((w0 / (2 * Math.PI)));
        return tab;
    }

    public void setR(double r) {
        this.R = r;
    }

    public void setC(double c) {
        this.C = c;
    }

    public void setFreq(double freq) {
        this.frequence = freq;
    }

    public CurveFunction TracePhi(double r, double c) {
        return ((x) -> -1 * Math.atan(r * c * x * 2 * Math.PI));
    }

    public CurveFunction TraceGain(double r, double c) {
        return ((x) -> (1 / (Math.pow(1 + Math.pow(r * c * x * 2 * Math.PI, 2), 0.5))));
    }

    public CurveFunction test(double a, double b) {
        return ((x) -> (a / 100) * x + (b / 100));
    }

}
