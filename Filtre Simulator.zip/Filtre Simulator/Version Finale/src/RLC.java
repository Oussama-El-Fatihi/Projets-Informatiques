
public class RLC extends Filtre {
	/**
	 * Classe RLC : permet de générer un filtre RLC
	 */
   protected double R;//  valeur de la résistance
    protected double C;// valeur du condensteur
    protected double L;// valeur de la bobbine
    
    
    
	/**
	 * constructeur
	 * fréquence, résistance, condensateur et bobbine fixées à zéro
	 */
    public RLC() {
        super(0);
        R = 0;
        C = 0;
        L = 0;

    }
	/**
	 * constructeur
	 * @param fréquence du signql à filtrer
	 * @param résistance 
	 * @param condensateur
	 * @param bobbine
	 */
    public RLC(double f, double r, double c, double l) {
        super(f);
        R = r;
        C = c;
        L = l;
    }

    /**
	 *calcul le gain à une certaine fréquence
	 * @param fréquence
	 * @return le gain à la fréquence donnée
	 */	
    public double CalculGain1(double f) {
        double a = this.L * this.C * 4 * Math.pow(Math.PI, 2);// allège l'expression dans le return
        double b = this.R * this.C * 2 * Math.PI;
        return (Math.pow(Math.pow(1 - a * frequence * f, 2) + Math.pow(b * f, 2), -0.5));
    }

 
   	/**
	 *calcul le déphasage à une certaine fréquence
	 * @param fréquence
	 * @return le déphasage à la fréquence donnée
	 */
    public double CalculPhi1(double f) {
        double w0 = Math.pow(this.L * this.C, -0.5);
        double Q = 1 / (R * C * w0);
        return (-Math.PI / 2 - Math.atan(Q * (Math.pow((2 * Math.PI * f) / w0, 2) - 1) / ((2 * Math.PI * f) / w0)));
    }
    
    
    
    /**
	 *calcul les fréquences de coupure pour le filtre RLC
	 * @return deux fréquences de coupure
	 */
    public double[] CalculFc() {
        double[] tab = new double[2];
        tab[0] = Math.round(
                (this.CalculFr() * (1 - (1 / (2 * (double) 1 / (R * C * ((double) Math.sqrt(1 / (L * C)))))))) * 100.0)
                / 100.0;
        tab[1] = Math.round(
                (this.CalculFr() * (1 + (1 / (2 * (double) 1 / (R * C * ((double) Math.sqrt(1 / (L * C)))))))) * 100.0)
                / 100.0;
        return tab;
    }
    
    /**
	 *calcul la fréquence de résonnance 
	 * @return la fréquence de résonnance 
	 */
    public double CalculFr() {
        return Math.round(1 / (Math.sqrt(this.L * this.C) * 2 * Math.PI) * 100.0) / 100.0;
    }
    

    /**
	 *calcule le facteur qualité pour le filtre RLC
	 * @return facteur qualité
	 */
    public double CalculQual() {
        return Math.round(((1 / this.R) * Math.sqrt(this.L / this.C)) * 100.0) / 100.0;
    }

	/**
	 * fixe la valeur de la résistance
	 * @param résistance
	 */
    public void setR(double r) {
        this.R = r;
    }

    /**
	 * fixe la valeur du condensateur
	 * @param condensateur
	 */
    public void setC(double c) {
        this.C = c;
    }

    /**
	 * fixe la valeur de la bobbine
	 * @param bobbine
	 */
    public void setL(double l) {
        this.L = l;
    }

    /**
	 * fixe la fréquence 
	 * @param fréquence
	 */
    public void setFreq(double freq) {
        this.frequence = freq;
    }

    /**
	 * calcul la bande passante pour le filtre RLC
	 * @return bande passante
	 */
    public double CalculBD() {
        return Math.round(Math.abs(this.CalculFc()[0] - this.CalculFc()[1]) * 100.0) / 100.0;
    }
    
    
    /**
	 *traçe le déphasage pour RLC en fonction de la fréquence
	 * @param résistance
	 * @param condensateur 
	 * @param bobbine
	 */
    public CurveFunction TracePhiRLC(double r, double l, double c) {
        double w0 = 1 / Math.sqrt(l * c);//pulsation de résonnace et allège l'expression
        double q = 1 / (r * c * w0);//facteur qualité et allège l'expression
        return ((x) -> -Math.PI / 2 - Math.atan(q * (Math.pow(2 * Math.PI * x / w0, 2) - 1) / (2 * Math.PI * x / w0)));

    }
    
    
    /**
	 *traçe le gain en fonction de la fréquence pour RLC
	 * @param résistance
	 * @param condensateur 
	 * @param bobbine
	 */
    public CurveFunction TraceGainRLC(double r, double l, double c) {
        return ((x) -> (1
                / (Math.sqrt(Math.pow((1 - l * c * Math.pow(2 * Math.PI * x, 2)), 2)
                        + Math.pow((r * c * 2 * Math.PI * x), 2)))));

    }

    /**
	 *test le tracé
	 * @param a quelconque
	 * @param b quelconque
	 */
    public CurveFunction test(double a, double b) {
        return (x) -> a * x + b;
    }
    
    
 	/**
	 *traçe le déphasage en fonction de la fréquence
	 * @param résistance
	 * @param condensateur ou bobbine
	 */
	public CurveFunction TracePhi(double r, double c) {
        return null;//car filtre rlc
    }
    
    /**
	 *traçe le gain en fonction de la fréquence
	 * @param résistance
	 * @param condensateur ou bobbine
	 */
    public CurveFunction TraceGain(double r, double c) {
        return null;//car filtre rlc
    }
}
