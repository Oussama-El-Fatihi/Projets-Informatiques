public interface CurveFunction {
    // interface CurveFunction qui permet de calculer l'image par une fonction
    // donnée. Interface qui est redéfinie à chaque fois avec (x) -> f(x)
    public double compute(double x);

}
