public class triangle extends autreSignal {
	/**
	 * Classe triangle : permet de générer un signal triangulaire
	 */
	 
	 
	 /**
	 * constructeur
	 * @param amplitude du signal
	 * @param fréquence du générateur
	 * @param filtre appliqué au signal
	 */
	  public triangle (double amplitude, double frequenceEntree, Filtre f ){
		super (amplitude,frequenceEntree, f) ;
		a0entree=0;
		a0sortie=a0entree*f.CalculGain1(0.0);
	}
	
	/**
	 *calcul les coefficients bn de Fourier avant filtrage
	 */ 
	public void calculCoeffBnEntree(){
		bnEntree = new double [NB_HARMO];//bn=0		
	}
	
	/**
	 *calcul les coefficients an de Fourier avant filtrage
	 */
	public void calculCoeffAnEntree(){ 
		anEntree = new double [NB_HARMO];
		for (int i = 0 ; i< anEntree.length ; i++) {
			anEntree[i]= (8*amplitudeEntree)/(Math.pow(Math.PI*(2*i+1),2)) ; 
			
		} 
	} 
	
	/**
	 *calcul la série de Fourier avant filtrage pour un t donné
	 * @param t temps
	 * @return la valeur de la SF à un t donné
	 */
	public double calculSFEntree(double t){
		double sf=0;
		for(int i=0;i<bnEntree.length;i++){
			sf=sf+anEntree[i]*Math.cos(2*Math.PI*frequence*(2*i+1)*t);
		}
		
		
		return sf+a0entree;
	}
	
	/**
	 *calcul la série de Fourier après filtrage pour un t donné
	 * @param t temps
	 * @return la valeur de la SF à un t donné
	 */
	public double calculSFSortie(double t){
		double sf=0;
		for(int i=0;i<bnEntree.length;i++){
			sf=sf+anSortie[i]*Math.cos(2*Math.PI*frequence*(i+1)*t+phiSortie[i]);
		}
		return sf+a0sortie;
	}
}
