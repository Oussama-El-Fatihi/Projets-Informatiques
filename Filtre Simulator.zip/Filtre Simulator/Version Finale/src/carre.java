public class carre extends autreSignal {
	/**
	 * Classe carré : permet de générer un signal carré
	 */
	 
	 /**
	 * constructeur
	 * @param amplitude du signal
	 * @param fréquence du générateur
	 * @param filtre appliqué au signal
	 */
	
	public carre (double amplitude, double frequenceEntree, Filtre f ){
		super (amplitude,frequenceEntree, f) ;
		a0entree=0;
		a0sortie=0;
		
		}
	
	/**
	 *calcul les coefficients bn de Fourier avant filtrage
	 */
	public void calculCoeffBnEntree(){
		bnEntree = new double [NB_HARMO];
		for (int i = 0 ; i< bnEntree.length ; i++) {
			bnEntree[i]= (2*amplitudeEntree*(1- Math.pow((-1),(i+1) ) ) )/((i+1)*Math.PI) ; 
			
		}
			
	}
	
	/**
	 *calcul les coefficients an de Fourier avant filtrage
	 */
	public void calculCoeffAnEntree(){ 
		anEntree = new double [NB_HARMO]; // an = 0 pour toun n
	} 
	
	
	/**
	 *calcul la série de Fourier avant filtrage pour un t donné
	 * @param t temps
	 * @return la valeur de la SF à un t donné
	 */
	public double calculSFEntree(double t){
		double sf=0;
		for(int i=0;i<bnEntree.length;i++){
			sf=sf+bnEntree[i]*Math.sin(2*Math.PI*frequence*(i+1)*t);
		}
		
		
		return sf;
	}
	
	
	/**
	 *calcul la série de Fourier après filtrage pour un t donné
	 * @param t temps
	 * @return la valeur de la SF à un t donné
	 */
	public double calculSFSortie(double t){
		double sf=0;
		for(int i=0;i<bnEntree.length;i++){
			sf=sf+bnSortie[i]*Math.sin(2*Math.PI*frequence*(i+1)*t+phiSortie[i]);
		}
		return sf;
	}
	
	
	
	
	
	
	
}

