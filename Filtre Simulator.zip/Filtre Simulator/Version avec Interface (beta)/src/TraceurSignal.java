import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JComponent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import javax.swing.*;
import java.awt.*;

public class TraceurSignal extends JPanel {

    // fonction affichée par défaut f(x)= 0
    public CurveFunction function = (x) -> 0;
    public double X;
    public double Y;

    public TraceurSignal(String S, double V) {
        this.X = V;
        this.Y = this.X * 0.001;
        // this.setTitle("CurveTracer");
        this.setBounds(600, 200, 600, 600);
        this.setVisible(false);
        // this.setResizable(false) ;
        // this.setVisible(true) ;

        JLabel Text = new JLabel();
        Text.setBounds(10, 10, 100, 100);
        Text.setText(S);
        this.add(Text);
    }

    public TraceurSignal(String S) {
        this.X = 10;
        this.Y = 0.001;
        // this.setTitle("CurveTracer");
        this.setBounds(600, 200, 600, 600);
        this.setVisible(false);
        // this.setResizable(false) ;
        // this.setVisible(true) ;

        JLabel Text = new JLabel();
        Text.setBounds(10, 10, 100, 100);
        Text.setText(S);
        this.add(Text);
    }

    public void paint(Graphics Thegraphics) {

        // ANTIALIASING : POUR RENDRE LA COURBE PLUS LISSE
        Graphics2D graphics = (Graphics2D) Thegraphics;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // dessin des axes etc.
        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, getWidth(), getHeight());

        graphics.setColor(Color.GRAY);
        graphics.drawLine(0, getHeight() / 2, getWidth(), getHeight() / 2);
        graphics.drawLine(getWidth() / 2, 0, getWidth() / 2, getHeight());

        graphics.setColor(Color.BLACK);
        graphics.drawString("0,0", (int) (getWidth() * 0.51), (int) (getHeight() * 0.54));
        graphics.drawString("-20", (int) (getWidth() * 0.02), (int) (getHeight() * 0.54));
        graphics.drawString("20", (int) (getWidth() * 0.96), (int) (getHeight() * 0.54));

        // dessin de la courbe sous la forme de plusieurs très petits segments
        // consécutifs ce qui donne la forme d'une courbe
        double step = this.Y;
        graphics.setColor(Color.red);

        int oldX = xToPixel(-this.X);
        int oldY = yToPixel(function.compute(-this.X));

        for (double a = -this.X + step; a <= this.X + step; a += step) {
            int x = xToPixel(a);
            int y = yToPixel(function.compute(a));

            graphics.drawLine(x, y, oldX, oldY);

            oldX = x;
            oldY = y;
        }

    }

    // permet de définir la fonction à tracer
    public void setFunction(CurveFunction function) {
        this.function = function;
        repaint();
    }

    public void setFunction(CurveFunction function, double W) {
        this.X = W;
        this.Y = X * 0.001;
        this.function = function;

        repaint();
    }

    private int xToPixel(double x) {
        return (int) (getWidth() * (x + this.X) / (2 * this.X));
    }

    private int yToPixel(double y) {
        return (int) (getHeight() * (1 - (y + 10) / 20.0));
    }

}
