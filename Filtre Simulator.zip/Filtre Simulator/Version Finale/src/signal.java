import java.util.*;

public abstract class signal extends TraceurCourbe {
	/**
	 * Classe signal : permet de générer un signal 
	 */
	protected double frequence;//frequence du générateur
	protected double amplitudeEntree;//amplitude du signal
	protected Filtre f;//filtre appliqué
	
	/**
	 * constructeur
	 * @param amplitude du signal
	 * @param fréquence du générateur
	 * @param filtre appliqué au signal
	 */
	public signal(double frequence, double amplitude, Filtre f1) {
		super("S");
		this.frequence = frequence;
		this.amplitudeEntree = amplitude;
		f = f1;

	}

	/**
	 * fixe le filtre utilisé
	 * @param filtre
	 */
	public abstract void setFiltre(Filtre f);
	
	/**
	 * fixe la fréquence du générateur
	 * @param fréquence
	 */
	public abstract void setfreq(double freq);
	
		
	/**
	 *traçe le signal d'entrée
	 */
	public abstract CurveFunction signalentree();
	

	/**
	 *traçe le signal de sortie 
	 */
	public abstract CurveFunction signalsortie();

}

