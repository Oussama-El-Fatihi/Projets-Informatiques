public class triangle extends autreSignal {
        
	public triangle (double amplitude, double frequenceEntree, Filtre f ){
		  super (amplitude,frequenceEntree, f) ;
		  a0entree=0;
		  a0sortie=a0entree*f.CalculGain1(0.0);
  }
  
  //entree
  
  public void calculCoeffBnEntree(){
		  bnEntree = new double [100];
		  
				  
  }
  public void calculCoeffAnEntree(){ // an = 0 donc ok
		  anEntree = new double [100];
		  for (int i = 0 ; i< anEntree.length ; i++) {
				  anEntree[i]= (8*amplitudeEntree)/(Math.pow(Math.PI*(2*i+1),2)) ;
				  
		  }
  }
  public double calculSFEntree(double t){
		  double sf=0;
		  for(int i=0;i<bnEntree.length;i++){
				  sf=sf+anEntree[i]*Math.cos(2*Math.PI*frequence*(2*i+1)*t);
		  }
		  
		  
		  return sf+a0entree;
  }
  
  
  //sortie
  
  public double calculSFSortie(double t){
		  double sf=0;
		  for(int i=0;i<bnEntree.length;i++){
				  sf=sf+anSortie[i]*Math.cos(2*Math.PI*frequence*(i+1)*t+phiSortie[i]);
		  }
		  return sf+a0sortie;
  }
}