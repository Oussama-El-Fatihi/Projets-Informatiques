import java.util.*;

public class sinusoidal extends signal {
	protected double phaseEntree;
	protected double amplitudeSortie;
	protected double phaseSortie;

	public sinusoidal(double frequence, double amplitude, double phase, Filtre f1) {
		super(frequence, amplitude, f1);
		phaseEntree = phase;
		this.sortie();
	}

	public void sortie() {
		this.amplitudeSortie = this.amplitudeEntree * this.f.CalculGain1(this.frequence);
		this.phaseSortie = this.phaseEntree + this.f.CalculPhi1(this.frequence);

	}

	public String toString() {
		return "signal sinusoidal de fréquence" + this.frequence + " Hz" + "d'amplitude" + this.amplitudeEntree
				+ "de phase"
				+ this.phaseEntree + "avec un filtre de type" + this.f;
	}

	public void setFiltre(Filtre f) {
		this.f = f;
		this.sortie();
		//this.amplitudeSortie = this.amplitudeEntree * this.f.CalculGain1(this.frequence);
		//this.phaseSortie = this.phaseEntree + this.f.CalculPhi1(this.frequence);
	}

	public void setfreq(double freq) {
		this.frequence = freq;
		//this.amplitudeSortie = this.amplitudeEntree * this.f.CalculGain1(this.frequence);
		//this.phaseSortie = this.phaseEntree + this.f.CalculPhi1(this.frequence);
		this.sortie();
	}
	
	public double freqMin(LinkedList<sinusoidal> a){
		double frqmin=a.get(0).frequence;
		for (sinusoidal s : a) {
			if(s.frequence<frqmin){
				frqmin=s.frequence;
			}
		}
		return frqmin;
	}


	public CurveFunction signalentree() {
		this.sortie();
		return (x) -> amplitudeEntree * Math.cos(2 * Math.PI * frequence * x + phaseEntree);
	}

	public CurveFunction signalsortie() {
		this.sortie();
		return (x) -> amplitudeSortie * Math.cos(2 * Math.PI * frequence * x + phaseSortie);

	}

	public double calculSommeEntree(LinkedList<sinusoidal> a, double t) {
		double somme = 0;
		for (sinusoidal s : a) {
			somme = somme + s.amplitudeEntree * Math.cos(2 * Math.PI * s.frequence * t + s.phaseEntree);
		}
		return somme;
	}

	public CurveFunction sommeSignalEntree(LinkedList<sinusoidal> sommeSinusoide) {
		return (x) -> calculSommeEntree(sommeSinusoide, x);

	}

	public double calculSommeSortie(LinkedList<sinusoidal> a, double t) {
		double somme = 0;
		for (sinusoidal s : a) {
			somme = somme + s.amplitudeSortie * Math.cos(2 * Math.PI * s.frequence * t + s.phaseSortie);
		}
		return somme;
	}
	
	

	public CurveFunction sommeSignalSortie(LinkedList<sinusoidal> sommeSinusoide) {
		return (x) -> calculSommeSortie(sommeSinusoide, x);

	}
	
	/** test methode min
	public static void main(String args[]) {
		LinkedList<sinusoidal> sommeSinusoide=new LinkedList<sinusoidal> ();
		double f=1000;
		double r=1000;
		double nano=Math.pow(10,-9);
		double c=101.3*nano;
		
		Filtre fil=new RC(0,r,c);
		sommeSinusoide.add(new sinusoidal(0.8,4,0,fil));
		sommeSinusoide.add(new sinusoidal(0.5,4,0,fil));
		sommeSinusoide.add(new sinusoidal(70,5,0,fil));
		System.out.println(sommeSinusoide.getFirst().freqMin(sommeSinusoide));
	
	}
	**/

}

/*
 * if (ChoixSin == 1) {
 * Sign.setFiltre(FiltreF);
 * } else {
 * if (ChoixSin == 2) {
 * for (sinusoidal Som : sommeSin) {
 * Som.setFiltre(FiltreF);
 * }
 * }
 * }
 * 
 */
