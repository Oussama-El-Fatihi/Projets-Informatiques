public abstract class  autreSignal extends signal { 
	/**
	 * Classe autreSignal : permet de générer les signaux periodiques non sinusoidale
	 */
	protected double a0entree ;//valeur moyenne
	protected double[] anEntree ; //coefficient an de la série de Fourier avant filtrage
	protected double[] bnEntree ;//coefficient bn de la série de Fourier avant filtrage
	
	protected double a0sortie; //valeur moyenne après filtrage
	protected double[] anSortie ; //coefficient an de la série de Fourier après filtrage
	protected double[] bnSortie ; //coefficient bn de la série de Fourier après filtrage
	protected double[] phiSortie;//valeurs du déphasage à l'origine après filtrage
	protected final int NB_HARMO=100; //nombre d'harmoniques fixés à 100
	
	/**
	 * constructeur
	 * @param amplitude du signal
	 * @param fréquence du générateur
	 * @param filtre appliqué au signal
	 */
	
	public autreSignal (double amplitude, double frequenceEntree, Filtre f){
		super (frequenceEntree, amplitude, f);
		calculCoeffBnEntree(); 
		calculCoeffAnEntree ();
		calculCoeffBnSortie();
		calculCoeffAnSortie();
		calculPhiSortie();
	}
	/**
	 *calcul les coefficients an de Fourier avant filtrage
	 */
	public abstract void calculCoeffBnEntree(); 
	
	/**
	 *calcul les coefficients bn de Fourier avant filtrage
	 */
	public abstract void calculCoeffAnEntree();
	
	/**
	 *calcul la série de Fourier avant filtrage pour un t donné
	 * @param t temps
	 * @return la valeur de la SF à un t donné
	 */
	public abstract double calculSFEntree(double t );

	 
	/**
	 *calcul la série de Fourier après filtrage pour un t donné
	 * @param t temps
	 * @return la valeur de la SF à un t donné
	 */
	public abstract double calculSFSortie(double t );
	
	
	/**
	 *traçe le signal d'entrée
	 */
	public CurveFunction signalentree(){
		return ((x)->calculSFEntree(x));
	}
	
	
	/**
	 *calcul les coefficients an de Fourier après filtrage
	 */
	public void calculCoeffAnSortie(){
		anSortie = new double [NB_HARMO] ;
		for (int i = 0 ; i<bnSortie.length; i++){
			anSortie[i] = anEntree[i]*f.CalculGain1((i+1)*frequence); 
		} 
	} 
	
	/**
	 *calcul les coefficients bn de Fourier après filtrage
	 */
	public void calculCoeffBnSortie(){
		bnSortie = new double [NB_HARMO] ;
		for (int i = 0 ; i<bnSortie.length; i++){
			bnSortie[i] = bnEntree[i]*f.CalculGain1((i+1)*frequence); 
		} 
	}
	
	/**
	 *calcul les valeurs du déphasage à l'origine après filtrage
	 */
	public void calculPhiSortie(){
		phiSortie = new double [NB_HARMO] ;
		for (int i = 0 ; i<bnSortie.length; i++){
			phiSortie[i] =f.CalculPhi1((i+1)*frequence); 
		} 
	} 
	
	/**
	 * fixe le filtre utilisé
	 * @param filtre
	 */
	public void setFiltre(Filtre f){
		this.f = f;
		//mise à jour des coefficients de fourier de sortie après changement de filtre
		calculCoeffBnSortie();
		calculCoeffAnSortie();
		calculPhiSortie();
	}
	
	/**
	 * fixe la fréquence du générateur
	 * @param fréquence
	 */
	public void setfreq(double freq) {
		this.frequence = freq;
		//mise à jour des coefficients de fourier de sortie après changement de fréquence du générateur
		calculCoeffBnSortie();
		calculCoeffAnSortie();
		calculPhiSortie();
	}
	
	/**
	 *traçe le signal de sortie 
	 */
	public CurveFunction signalsortie(){
		return ((x)->calculSFSortie(x));
	}
	
}
