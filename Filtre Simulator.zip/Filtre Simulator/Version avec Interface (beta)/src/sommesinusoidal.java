import java.util.*;
public class sommesinusoidal extends sinusoidal {
	protected LinkedList <sinusoidal> sommeSinus;

	public sommesinusoidal( LinkedList <sinusoidal> sum) {
		sommeSinus=sum;	
	}
		
	

	

}
