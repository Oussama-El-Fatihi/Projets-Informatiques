import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JComponent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.event.ActionEvent;
import javax.swing.*;
import java.awt.*;

public class TraceurCourbe extends JPanel {

    // fonction affichée par défaut f(x)= 0
    public CurveFunction function = (x) -> 0;

    public double X;

    public TraceurCourbe(String S, double W) {
        this.X = W;
        // this.setTitle("CurveTracer");
        this.setBounds(600, 200, 600, 600);
        this.setVisible(false);
        // this.setResizable(false) ;
        // this.setVisible(true) ;

        JLabel Text = new JLabel();
        Text.setBounds(10, 10, 100, 100);
        Text.setText(S);
        this.add(Text);

    }

    public TraceurCourbe(String S) {
        this.X = 10000;
        // this.setTitle("CurveTracer");
        this.setBounds(600, 200, 600, 600);
        this.setVisible(false);
        // this.setResizable(false) ;
        // this.setVisible(true) ;

        JLabel Text = new JLabel();
        Text.setBounds(10, 10, 100, 100);
        Text.setText(S);
        this.add(Text);

    }

    public void paint(Graphics Thegraphics) {

        // ANTIALIASING : POUR RENDRE LA COURBE PLUS LISSE
        Graphics2D graphics = (Graphics2D) Thegraphics;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // dessin des axes etc.
        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, getWidth(), getHeight());

        graphics.setColor(Color.GRAY);
        // graphics.drawLine(0, 0, 0, getHeight() / 2);
        graphics.drawLine(0, getHeight() / 2, getWidth(), getHeight() / 2);
        // graphics.drawLine(0, getHeight() / 2, getWidth(), getHeight() / 2);
        graphics.drawLine(0, 0, 0, getHeight());

        graphics.setColor(Color.BLACK);
        graphics.drawString("0,0", (int) (0), (int) (getHeight() * 0.54));
        // graphics.drawString("-1", (int) (getWidth() * 0.02), (int) (getHeight() *
        // 0.54));
        graphics.drawString("f (Hz)", (int) (getWidth() * 0.90), (int) (getHeight() * 0.54));

        // dessin de la courbe sous la forme de plusieurs très petits segments
        // consécutifs ce qui donne la forme d'une courbe
        double step = 0.01;
        graphics.setColor(Color.red);

        int oldX = xToPixel(0);
        int oldY = yToPixel(function.compute(0));

        for (double a = step; a <= this.X + step; a += step) {
            int x = xToPixel(a);
            int y = yToPixel(function.compute(a));

            graphics.drawLine(x, y, oldX, oldY);

            oldX = x;
            oldY = y;
        }

    }

    // permet de définir la fonction à tracer
    public void setFunction(CurveFunction function) {
        this.function = function;
        repaint();
    }

    public void setFunction(CurveFunction function, double W) {
        this.X = W;
        this.function = function;
        repaint();
    }

    private int xToPixel(double x) {
        return (int) (getWidth() * (x) / (this.X));
    }

    private int yToPixel(double y) {
        return (int) (getHeight() * (1 - (y + 2) / (2 * 2)));
    }

}
