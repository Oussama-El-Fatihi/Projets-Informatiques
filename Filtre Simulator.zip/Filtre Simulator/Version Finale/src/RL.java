
public class RL extends Filtre {
	
	/**
	 * Classe RL : permet de générer un filtre RL
	 */

	
    protected double R;//  valeur de la résistance 
    protected double L;// valeur de la bobbine
    
    
	/**
	 * constructeur
	 * @param fréquence du signal à filtrer
	 * @param résistance 
	 * @param bobbine
	 */
    public RL(double f, double r, double l) {
        super(f); // Ã vÃ©rifier
        this.R = r;
        this.L = l;

    }
    
	/**
	 * constructeur
	 * fréquence, résistance, bobbine fixées à zéro
	 */
    public RL() {
        super(0);
        R = 0;
        L = 0;

    }
    
    
    
	/**
	 * permet de tester les valeur de résistance et bobbine
	 */
    public String toString() {
        return super.toString() + " composÃ©e d'une rÃ©sistance de " + this.R + " Ohm et d'une bobbine de " + this.L
                + " F.";
    }
    
    

    /**
	 *calcul le gain à une certaine fréquence
	 * @param fréquence
	 * @return le gain à la fréquence donnée
	 */	
    public double CalculGain1(double f) {
        double a = L * 2 * Math.PI / R;
        return (a * f / Math.pow(1 + Math.pow(a * f, 2), 0.5));
    }


    
	/**
	 *calcul le déphasage à une certaine fréquence
	 * @param fréquence
	 * @return le déphasage à la fréquence donnée
	 */
    public double CalculPhi1(double f) {
        double a = L * 2 * Math.PI / R;// allège l'expression dans le return
        return (-Math.PI / 2 - Math.atan(a * f));
    }
    
    
    /**
	 *calcul la fréquence de résonnance 
	 * @return la fréquence de résonnance 
	 */
    public double CalculFr() {
        return Math.round((this.R / (this.L * 2 * Math.PI)) * 100.0) / 100.0;
    }
    
    /**
	 * calcul la bande passante pour le filtre RLC
	 * @return bande passante
	 */
	 public double CalculBD(){
		 return 0;
	 }
	 
	 
	/**
	 *calcul les fréquences de coupure pour le filtre RLC
	 * @return deux fréquences de coupure
	 */
    public double[] CalculFc() {
        double[] tab = new double[2];//on retourne rien car pas deux fréquences de résonnance pour filtre RL
        return tab;
    }
    
    
	/**
	 * fixe la valeur de la résistance
	 * @param résistance
	 */
    public void setR(double r) {
        this.R = r;
    }
    
    
    /**
	 * fixe la valeur de la bobbine
	 * @param bobbine
	 */
    public void setL(double l) {
        this.L = l;
    }
    
    
    /**
	 * fixe la valeur du condensateur
	 * @param condensateur
	 */
    public void setC(double l) {
        this.R = R;
    }
    
    
    /**
	 * fixe la fréquence 
	 * @param fréquence
	 */
    public void setFreq(double freq) {
        this.frequence = freq;
    }


    /**
	 *calcule le facteur qualité pour le filtre RLC
	 * @return facteur qualité
	 */
    public double CalculQual() {
        return 0;//pas de faceteur qualité pour RL
    }

	/**
	 *traçe le déphasage en fonction de la fréquence
	 * @param résistance
	 * @param condensateur ou bobbine
	 */
    public CurveFunction TracePhi(double r, double l) {
        return ((x) -> (Math.atan(r / (l * x * 2 * Math.PI))));
    }


   
    /**
	 *traçe le gain en fonction de la fréquence
	 * @param résistance
	 * @param condensateur ou bobbine
	 */
    public CurveFunction TraceGain(double l, double r) {

        return ((x) -> ((l * x * 2 * Math.PI / r) / Math.pow(1 + Math.pow((l * x * 2 * Math.PI / r), 2), 0.5)));
    }


    /**
	 *test le tracé
	 * @param a quelconque
	 * @param b quelconque
	 */
    public CurveFunction test(double a, double b) {
        return (x) -> a * x + b;
    }


    /**
	 *traçe le déphasage pour RLC en fonction de la fréquence
	 * @param résistance
	 * @param condensateur 
	 * @param bobbine
	 */
    public CurveFunction TracePhiRLC(double r, double l, double c) {
        return null;// car pas RLC
    }


    /**
	 *traçe le gain en fonction de la fréquence pour RLC
	 * @param résistance
	 * @param condensateur 
	 * @param bobbine
	 */
    public CurveFunction TraceGainRLC(double r, double l, double c) {
        return null;//car pas RLC
    }

}
