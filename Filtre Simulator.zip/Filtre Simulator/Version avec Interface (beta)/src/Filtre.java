import java.util.function.Function;
import java.util.*;

public abstract class Filtre extends TraceurCourbe implements OutilsFiltre {
    protected double frequence;

    public Filtre(double frequence) {
        super("S");
        this.frequence = frequence;
    }

    public String toString() {
        return "Filtre " + this.frequence + " Hz";
    }

}
