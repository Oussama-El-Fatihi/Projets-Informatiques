import java.util.*;

public abstract class signal extends TraceurCourbe {
	protected double frequence;
	protected double amplitudeEntree;
	protected Filtre f;

	public signal(double frequence, double amplitude, Filtre f1) {
		super("S");
		this.frequence = frequence;
		this.amplitudeEntree = amplitude;
		f = f1;

	}

	//public void setFiltre(Filtre f) {
		//this.f = f;
		
		
	//}

	//public void setfreq(double freq) {
		//this.frequence = freq;
	//}
	public abstract void setFiltre(Filtre f);
	
	public abstract void setfreq(double freq);
		

	public abstract CurveFunction signalentree();

	public abstract CurveFunction signalsortie();

}

