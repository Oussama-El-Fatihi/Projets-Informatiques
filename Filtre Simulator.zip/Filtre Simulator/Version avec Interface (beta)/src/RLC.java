public class RLC extends Filtre {
    protected double R;
    protected double C;
    protected double L;

    public RLC() {
        super(0);
        R = 0;
        C = 0;
        L = 0;

    }

    public RLC(double f, double r, double c, double l) {
        super(f);
        R = r;
        C = c;
        L = l;
    }

    public String toString() {
        return super.toString() + "blablabla";
    }

    public double CalculGain() {
        double a = this.L * this.C * 4 * Math.pow(Math.PI, 2);
        double b = this.R * this.C * 2 * Math.PI;
        return (Math.pow(Math.pow(1 - a * frequence * frequence, 2) + Math.pow(b * frequence, 2), -0.5));
    }

    public double CalculGain1(double f) {
        double a = this.L * this.C * 4 * Math.pow(Math.PI, 2);
        double b = this.R * this.C * 2 * Math.PI;
        return (Math.pow(Math.pow(1 - a * frequence * f, 2) + Math.pow(b * f, 2), -0.5));
    }

    public double CalculPhi() {
        double w0 = Math.pow(this.L * this.C, -0.5);
        double Q = 1 / (R * C * w0);
        return (-Math.PI / 2
                - Math.atan(Q * (Math.pow((2 * Math.PI * frequence) / w0, 2) - 1) / ((2 * Math.PI * frequence) / w0)));
    }

    public double CalculPhi1(double f) {
        double w0 = Math.pow(this.L * this.C, -0.5);
        double Q = 1 / (R * C * w0);
        return (-Math.PI / 2 - Math.atan(Q * (Math.pow((2 * Math.PI * f) / w0, 2) - 1) / ((2 * Math.PI * f) / w0)));
    }

    public double[] CalculFc() {
        double[] tab = new double[2];
        tab[0] = Math.round(
                (this.CalculFr() * (1 - (1 / (2 * (double) 1 / (R * C * ((double) Math.sqrt(1 / (L * C)))))))) * 100.0)
                / 100.0;
        tab[1] = Math.round(
                (this.CalculFr() * (1 + (1 / (2 * (double) 1 / (R * C * ((double) Math.sqrt(1 / (L * C)))))))) * 100.0)
                / 100.0;
        return tab;
    }

    public double CalculFr() {
        return Math.round(1 / (Math.sqrt(this.L * this.C) * 2 * Math.PI) * 100.0) / 100.0;
    }

    public double CalculQual() {
        return Math.round(((1 / this.R) * Math.sqrt(this.L / this.C)) * 100.0) / 100.0;
    }

    public void setR(double r) {
        this.R = r;
    }

    public void setC(double c) {
        this.C = c;
    }

    public void setL(double l) {
        this.L = l;
    }

    public void setFreq(double freq) {
        this.frequence = freq;
    }

    public double CalculBD() {
        return Math.round(Math.abs(this.CalculFc()[0] - this.CalculFc()[1]) * 100.0) / 100.0;
    }

    public CurveFunction TracePhiRLC(double r, double l, double c) {
        double w0 = 1 / Math.sqrt(l * c);
        double q = 1 / (r * c * w0);
        return ((x) -> -Math.PI / 2 - Math.atan(q * (Math.pow(2 * Math.PI * x / w0, 2) - 1) / (2 * Math.PI * x / w0)));

        /*
         * return ((x) -> -Math.PI / 2 - Math.atan((double) 1 / (r * c * ((double)
         * Math.sqrt(1 / (l * c))))
         * (Math.pow(((double) (2 * Math.PI * x) / ((double) Math.sqrt(1 / (l * c)))),
         * 2) + 1)));
         */
    }

    public CurveFunction TraceGainRLC(double r, double l, double c) {
        return ((x) -> (1
                / (Math.sqrt(Math.pow((1 - l * c * Math.pow(2 * Math.PI * x, 2)), 2)
                        + Math.pow((r * c * 2 * Math.PI * x), 2)))));

    }

    public CurveFunction test(double a, double b) {
        return (x) -> a * x + b;
    }
}
