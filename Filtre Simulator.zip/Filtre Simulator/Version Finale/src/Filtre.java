import java.util.function.Function;
import java.util.*;

	/**
	 * Classe Filtre : permet de générer un filtre entre RC, RLC, RL
	 */

public abstract class Filtre extends TraceurCourbe  {
  protected double frequence;
    
    
	/**
	 * constructeur
	 * @param fréquence du signal à filtrer
	 */
    public Filtre(double frequence) {
        super("S");
        this.frequence = frequence;
    }
    
    /**
	 *calcul le gain à une certaine fréquence
	 * @param fréquence
	 * @return le gain à la fréquence donnée
	 */	
    public abstract double CalculGain1(double f);
    
    
	/**
	 *calcul le déphasage à une certaine fréquence
	 * @param fréquence
	 * @return le déphasage à la fréquence donnée
	 */
    public abstract double CalculPhi1(double f);
    
    
    
	/**
	 * fixe la valeur de la résistance
	 * @param résistance
	 */
    public abstract void setR(double r);
    
    /**
	 *calcul la fréquence de résonnance pour les filtres RL et RC
	 * @return la fréquence de résonnance 
	 */
    public abstract double CalculFr(); 
    
	/**
	 *calcul les fréquences de coupure pour le filtre RLC
	 * @return deux fréquences de coupure
	 */
    public abstract double[] CalculFc();
    
    /**
	 * calcul la bande passante pour le filtre RLC
	 * @return bande passante
	 */
    public abstract double CalculBD();
    
	/**
	 * fixe la valeur de la bobbine
	 * @param bobbine
	 */
    public abstract void setL(double l);
    
    
	/**
	 * fixe la valeur du condensateur
	 * @param condensateur
	 */
    public abstract void setC(double c);
	  
    
    /**
	 * fixe la fréquence 
	 * @param fréquence
	 */
    public abstract void setFreq(double freq);

    
    /**
	 *calcule le facteur qualité pour le filtre RLC
	 * @return facteur qualité
	 */
    public abstract double CalculQual();
   
   
    /**
	 *traçe le gain en fonction de la fréquence
	 * @param résistance
	 * @param condensateur ou bobbine
	 */
    public abstract CurveFunction TraceGain(double r, double c);
    
	/**
	 *traçe le déphasage en fonction de la fréquence
	 * @param résistance
	 * @param condensateur ou bobbine
	 */
    public abstract CurveFunction TracePhi(double r, double c);
    
    /**
	 *traçe le déphasage pour RLC en fonction de la fréquence
	 * @param résistance
	 * @param condensateur 
	 * @param bobbine
	 */
    public abstract CurveFunction TracePhiRLC(double r, double l, double c);
    
    /**
	 *traçe le gain en fonction de la fréquence pour RLC
	 * @param résistance
	 * @param condensateur 
	 * @param bobbine
	 */
    public abstract CurveFunction TraceGainRLC(double r, double l, double c);


    /**
	 *test le tracé
	 * @param a quelconque
	 * @param b quelconque
	 */
    public abstract CurveFunction test(double a, double b);
    
    


    
}




